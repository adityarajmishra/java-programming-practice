package com.chatter.platform.commands;

public interface Command {
    String execute(String[] args);
}
