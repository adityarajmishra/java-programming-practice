package evaluations.level1.enums;

public enum TrafficLight {
    RED,
    YELLOW,
    GREEN;

}


