package evaluations.level1;

public class Calculator {

    public void add(int a, int b) {
        System.out.println("int addition");
    }

    public void add(float a, float b) {
        System.out.println("float addition");
    }

    public void add(double a, double b) {
        System.out.println("float addition");
    }

    public void add(long a, long b) {
        System.out.println("float addition");
    }

}
