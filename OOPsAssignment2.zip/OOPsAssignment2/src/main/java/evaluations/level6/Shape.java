package evaluations.level6;

public interface Shape {
    public void draw();

    public void about();
}
