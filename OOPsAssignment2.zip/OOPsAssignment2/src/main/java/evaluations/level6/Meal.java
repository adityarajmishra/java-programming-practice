package evaluations.level6;

public abstract class Meal {
    abstract public void cook();

    public void calories() {
        System.out.println("Skip counting calories. Eat and live freely.");
    }

}
