package evaluations.level4;

public interface Vehicle {
    void start();
    void accelerate(int speed);
    void brake();
}
