package evaluations.level4;

public interface MyCustomizableFunction {

    public int hash(int input);
}
